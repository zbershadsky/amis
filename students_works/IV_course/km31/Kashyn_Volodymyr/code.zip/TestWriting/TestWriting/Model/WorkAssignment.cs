﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestWriting.Model
{
    public class WorkAssignment
    {
        public string WorkName { get; set; }
        public string ExerciseName { get; set; }
        public string Subject { get; set; }
        public string Theme { get; set; }
        public string Teacher { get; set; }
        public string StudentNum { get; set; }
        public string StudentAnswer { get; set; }
        public int    WorkPoint { get; set; }


        public string Status
        {
            get 
            {
                if (StudentAnswer == null || StudentAnswer.Length < 1)
                {
                    return "Not passed";
                }

                if (WorkPoint > 0)
                {
                    return "Checked";
                }

                return "";

            }
        
        }

        public WorkAssignment()
        {}

        public WorkAssignment(WorkExercise we)
        {
            this.WorkName = we.WorkName;
            this.ExerciseName = we.ExerciseName;
            this.Subject = we.Subject;
            this.Theme = we.Theme;
            this.Teacher = we.Teacher;
        }


       

    }
}
