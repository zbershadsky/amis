﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Oracle.DataAccess.Client;
using System.Data;

namespace TestWriting.Model
{
    public class WorkAssignmentRepository: IRepository<WorkAssignment>, IDisposable
    {
        OracleConnection connection;

        public WorkAssignmentRepository()
        {
            Database db = new Database();
            connection = db.Connect();
        }

        public WorkAssignmentRepository(OracleConnection connection)
        {
            this.connection = connection;
        }


        public WorkAssignment FindById(string workName, string taskName, string subject, string theme, string teacher, string studentNum)
        { 
        
            OracleCommand command = new OracleCommand
            {
                CommandText = @"SELECT * FROM work_list 
                                    WHERE workname    = :param_workname
                                      AND exercisename = :param_exercisename
                                      AND subject = :param_subject
                                      AND theme = :param_theme
                                      AND teacher = :param_teacher
                                      AND studentnum = :studentnum",
                Connection = this.connection
            };

            command.Parameters.Add(":param_workname", OracleDbType.Varchar2).Value = workName;
            command.Parameters.Add(":param_exercisename", OracleDbType.Varchar2).Value = taskName;
            command.Parameters.Add(":param_theme", OracleDbType.Varchar2).Value = theme;
            command.Parameters.Add(":param_subject", OracleDbType.Varchar2).Value = subject;
            command.Parameters.Add(":param_teacher", OracleDbType.Varchar2).Value = teacher;
            command.Parameters.Add(":param_studentnum", OracleDbType.Varchar2).Value = studentNum;

            IDataReader reader = command.ExecuteReader();

            if (reader.Read())
            {
                WorkAssignment workAssignment = PopulateEntity(reader);
                return workAssignment;
            }

            return null;
             
        }

        public List<WorkAssignment> GetByStudent(string studentNum)
        {
            OracleCommand command = new OracleCommand("SELECT * FROM work_assignment_grouped WHERE studentnum = :param_studentnum", this.connection);

            command.Parameters.Add(":param_studentnum", OracleDbType.Varchar2).Value = studentNum;

            IDataReader reader = command.ExecuteReader();

            List<WorkAssignment> workAssignments = new List<WorkAssignment>();

            while (reader.Read())
            {
                WorkAssignment workAssignment = PopulateEntity(reader);
                workAssignments.Add(workAssignment);
            }

            return workAssignments;
        
        
        }

        protected WorkAssignment PopulateEntity(IDataReader reader)
        {
            WorkAssignment workAssignment = new WorkAssignment();

            workAssignment.WorkName = Database.GetStringFromReader(reader, "workname");
            workAssignment.ExerciseName = Database.GetStringFromReader(reader, "exercisename");
            workAssignment.Subject = Database.GetStringFromReader(reader, "subject");
            workAssignment.Theme = Database.GetStringFromReader(reader, "theme");
            workAssignment.Teacher = Database.GetStringFromReader(reader, "teacher");
            workAssignment.StudentNum = Database.GetStringFromReader(reader, "studentnum");
            workAssignment.StudentAnswer = Database.GetStringFromReader(reader, "answer");
            workAssignment.WorkPoint = Int32.Parse(reader["point"].ToString());

            return workAssignment;

        }


        public void Insert(WorkAssignment workAssignment)
        {
            
            OracleTransaction tr = null;

            OracleCommand command = new OracleCommand
            {
                CommandText = @"INSERT INTO work_assignment (fk_work_name, fk_exercise_name, fk_subject, 
                                            fk_theme, fk_teacher, fk_studentnum, student_answer, work_point)
                                        VALUES (:param_workname, :param_exercisename, :param_subject, :param_theme, 
                                            :param_teacher, :param_studentnum, :param_answer, :param_point)",


                Connection = this.connection
            };

            if (command.Transaction.IsolationLevel != IsolationLevel.Serializable)
            {
                tr = this.connection.BeginTransaction(IsolationLevel.Serializable);
            }

            command.Parameters.Add(":param_workname", OracleDbType.Varchar2).Value = workAssignment.WorkName;
            command.Parameters.Add(":param_exercisename", OracleDbType.Varchar2).Value = workAssignment.ExerciseName;
            command.Parameters.Add(":param_theme", OracleDbType.Varchar2).Value = workAssignment. Theme;
            command.Parameters.Add(":param_subject", OracleDbType.Varchar2).Value = workAssignment.Subject;
            command.Parameters.Add(":param_teacher", OracleDbType.Varchar2).Value = workAssignment.Teacher;
            command.Parameters.Add(":param_studentnum", OracleDbType.Varchar2).Value = workAssignment.StudentNum;
            command.Parameters.Add(":param_answer", OracleDbType.Varchar2).Value = workAssignment.StudentAnswer;
            command.Parameters.Add(":param_point", OracleDbType.Int32).Value = workAssignment.WorkPoint;

            command.ExecuteNonQuery();

            if(tr != null)
                tr.Commit();
        
        }

        public void Update(WorkAssignment entity)
        {
            OracleCommand command = new OracleCommand
            {
                CommandText = @"UPDATE work_assignment SET
                                    student_answer = :param_answer 
                               WHERE fk_work_name = :w_name AND fk_subject = :we_subject AND fk_theme = :we_theme AND fk_teacher = :we_teacher AND fk_studentnum = :param_student",
                Connection = this.connection
            };

            command.Parameters.Add(":w_name", OracleDbType.Varchar2).Value = entity.WorkName;
            command.Parameters.Add(":we_subject", OracleDbType.Varchar2).Value = entity.Subject;
            command.Parameters.Add(":we_theme", OracleDbType.Varchar2).Value = entity.Theme;
            command.Parameters.Add(":we_teacher", OracleDbType.Varchar2).Value = entity.Teacher;
            command.Parameters.Add(":param_student", OracleDbType.Varchar2).Value = entity.StudentAnswer;
            command.Parameters.Add(":param_answer", OracleDbType.Varchar2).Value = entity.StudentAnswer;
            command.ExecuteNonQuery(); 
        }

        public List<WorkAssignment> ListOf(int count = 0)
        {
            throw new NotImplementedException();
        }

        public void Delete(WorkAssignment entity)
        {
            return;
        }

        public void Dispose()
        {
            connection.Close();
        }
    }
}
