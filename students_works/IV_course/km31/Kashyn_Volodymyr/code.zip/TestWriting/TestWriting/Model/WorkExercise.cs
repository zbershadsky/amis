﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestWriting.Model
{
    public class WorkExercise
    {
        public string WorkName { get; set; }
        public string ExerciseName { get; set; }
        public string Subject { get; set; }
        public string Theme { get; set; }
        public string Teacher { get; set; }
        public int Points { get; set; }
    }
}
