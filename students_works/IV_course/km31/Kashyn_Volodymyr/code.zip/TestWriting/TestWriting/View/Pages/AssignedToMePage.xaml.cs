﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TestWriting.Model;

namespace TestWriting.View.Pages
{
    /// <summary>
    /// Логика взаимодействия для AssignedToMePage.xaml
    /// </summary>
    public partial class AssignedToMePage : Page
    {
        public AssignedToMePage()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (datagrid.SelectedItem == null)
            {
                MessageBox.Show("No work was selected!");
                return;
            }

            WorkWritingWindow wnd = new WorkWritingWindow(datagrid.SelectedItem as WorkAssignment);
            wnd.ShowDialog();

        }

        private void DataGrid_Loaded(object sender, RoutedEventArgs e)
        {
            DataGrid datagrid = sender as DataGrid;

            using(WorkAssignmentRepository wa = new WorkAssignmentRepository())
            {
                datagrid.ItemsSource = wa.GetByStudent((Session.User as Student).StudentNum);
            }
        }
    }
}
