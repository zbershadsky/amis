﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TestWriting.Model;
using System.Data;

namespace TestWriting.View
{
    /// <summary>
    /// Логика взаимодействия для WorkWritingWindow.xaml
    /// </summary>
    public partial class WorkWritingWindow : Window
    {
        WorkAssignment WorkAssignment;
        List<KeyValuePair<Exercise, WorkExercise>> exercises;

        public WorkWritingWindow(WorkAssignment workAssignment)
        {
            WorkAssignment = workAssignment;

            InitializeComponent();

            
        }

        private void Button_Click()
        {

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            using(ExerciseRepository exRep = new ExerciseRepository())
            {
                IDataReader reader = exRep.FindByWorkAndSubjectAndThemeAndAuthor(WorkAssignment.WorkName, WorkAssignment.Subject, WorkAssignment.Theme, WorkAssignment.Teacher, WorkAssignment.StudentNum);

                int i = 0;
                tb_task.Text = "";
                while (reader.Read())
                {
                    i++;
                    string s = "Task "+ i.ToString()+". "+reader["Taskname"] + "(max points: "+reader["Points"].ToString()+")\n";
                    s += reader["e_task"].ToString();
                    s += "\n\n\n";

                    tb_task.Text += s;
                }

                
            
            }

            tb_answer.Text = "";


            

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            WorkAssignment.StudentAnswer = tb_answer.Text;
            using (WorkAssignmentRepository war = new WorkAssignmentRepository())
            {
                war.Update(WorkAssignment);
            }
            this.Close();
        }
    }
}
