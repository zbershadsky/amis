create view CARDSPAYMENTS as
SELECT P."payment_id" payment_ID,
P."paydate" PAYDATE,
P."amount" AMOUNT,
P."phone_number" PHONE_NUMBER,
P."CardNo" CARDNO,
C."Token" TOKEN,
C."CardName" CARDNAME,
C."login" LOGIN FROM "ROMA"."Payment" P JOIN "ROMA"."Cards"  C ON P."CardNo" = C."CardNo"
